<?php
// Filter form markup
function wc_filter_form() {
    ?>
    <!--<form id="wc-filter-form" method="get" action="">
        <input type="hidden" name="post_type" value="product" />
        
        <label for="wc-filter-start-date">Start Date:</label>
        <input type="text" id="wc-filter-start-date" name="start_date" class="datepicker" />

        <label for="wc-filter-end-date">End Date:</label>
        <input type="text" id="wc-filter-end-date" name="end_date" class="datepicker" />

        <label for="wc-filter-min-price">Min Price:</label>
        <input type="number" id="wc-filter-min-price" name="min_price" />

        <label for="wc-filter-max-price">Max Price:</label>
        <input type="number" id="wc-filter-max-price" name="max_price" />

        <input type="submit" value="Filter" />
    </form>-->
    <?php
}
?>