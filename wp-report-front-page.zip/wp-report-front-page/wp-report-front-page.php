<?php
/*
Plugin Name: WP Report Front Page
Description: Adds a date range and price filter to WooCommerce product listings.
Version: 1.0.0
Author: Your Name
*/

// Plugin code goes here
?>

<?php
// Enqueue scripts and styles
function wc_filter_enqueue_scripts() {
    if (is_shop() || is_product_taxonomy()) {
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui-datepicker-style', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_script('wc-filter-script', plugin_dir_url(__FILE__) . 'js/filter-script.js', array('jquery'), '1.0.0', true);
        wp_enqueue_style('wc-filter-style', plugin_dir_url(__FILE__) . 'css/filter-style.css', array(), '1.0.0');
    }
}
add_action('wp_enqueue_scripts', 'wc_filter_enqueue_scripts');
?>

<?php


add_shortcode('woo_filter_prd', 'woocommerce_date_filter_form');

// Display filter form
function woocommerce_date_filter_form() {  ?>

        <form method="get" action="<?php echo esc_url( home_url( '/index.php/shop/' ) ); ?>">
            <input type="hidden" name="post_type" value="product" />
            <input type="hidden" name="filter_by_date" value="1" />
            <label for="start_date"><?php esc_html_e( 'Start Date:', 'woocommerce-date-filter' ); ?></label>
            <input type="text" id="start_date" name="start_date" class="datepicker" />
            <label for="end_date"><?php esc_html_e( 'End Date:', 'woocommerce-date-filter' ); ?></label>
            <input type="text" id="end_date" name="end_date" class="datepicker" />
            <label for="wc-filter-min-price">Min Price:</label>
            <input type="number" id="wc-filter-min-price" name="min_price" />

            <label for="wc-filter-max-price">Max Price:</label>
            <input type="number" id="wc-filter-max-price" name="max_price" /> 
            <button type="submit"><?php esc_html_e( 'Filter', 'woocommerce-date-filter' ); ?></button>
        </form>
   

<?php } ?>

<?php 
// Modify product query based on selected date range
function woocommerce_date_filter_product_query( $query ) {
    if ( isset( $_GET['filter_by_date'] ) && isset( $_GET['start_date'] ) && isset( $_GET['end_date'] ) ) {
        $start_date = sanitize_text_field( $_GET['start_date'] );
        $end_date = sanitize_text_field( $_GET['end_date'] );

        if ( $start_date && $end_date ) {
            $query->set( 'date_query', array(
                array(
                    'after' => $start_date,
                    'before' => $end_date,
                    'inclusive' => true,
                ),
            ) );
        }
    }
}
add_action( 'woocommerce_product_query', 'woocommerce_date_filter_product_query'); ?>

